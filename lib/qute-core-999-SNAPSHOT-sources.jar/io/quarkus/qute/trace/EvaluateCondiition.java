package io.quarkus.qute.trace;

import java.util.List;
import java.util.concurrent.ExecutionException;

import io.quarkus.qute.Engine;
import io.quarkus.qute.ReflectionValueResolver;
import io.quarkus.qute.Template;
import io.quarkus.qute.TemplateNode;
import io.quarkus.qute.TextNode;

public class EvaluateCondiition {

    public static void main(String[] args) throws InterruptedException {

        Engine engine = Engine.builder().addDefaults().addValueResolver(new ReflectionValueResolver()).build();

        Template conditionTemplate = engine.parse("""
                {#if item_count > 1}FOO{/if}
                """);

        TemplateNode test = conditionTemplate.findNodes(o -> true).iterator().next();

        Template template = engine.parse("""
                <html>
                   {#for item in items}
                   {#if item_count > 0}FOO{/if}
                       {item} {item_count}
                   {/for}
                </html>
                """);

        engine.addTraceListener(new TraceListener() {
            private boolean ignoring;

            @Override
            public void onStartTemplate(TemplateEvent event) {
                // System.err.println("Starting template (id): " +
                // event.getTemplateInstance().getTemplate().getId());
            }

            @Override
            public void onBeforeResolve(ResolveEvent event) {
                try {
                    if (ignoring) {
                        return;
                    }
                    try {
                        ignoring = true;
                        boolean result = test.resolve(event.getContext()).thenApply(o -> {
                            if (o instanceof TextNode) {
                                return true;
                            }
                            return false;
                        }).toCompletableFuture().get();
                        System.err.println(result);
                    } finally {
                        ignoring = false;
                    }
                } catch (InterruptedException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                } catch (ExecutionException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
                // System.err.println("Before node resolve: " + event.getTemplateNode());
            }

            @Override
            public void onAfterResolve(ResolveEvent event) {
                if (ignoring) {
                    return;
                }
                System.err.println(
                        "After node resolve: " + event.getTemplateNode() + " in " + event.getEllapsedTime() + "ms");
            }

            @Override
            public void onEndTemplate(TemplateEvent event) {
                // System.err.println("Rendering template (id): " +
                // event.getTemplateInstance().getTemplate().getId()
                // + " in " + event.getEllapsedTime() + "ms");
            }
        });

        List<String> items = List.of("foo", "bar", "baz");
        String s = template.data("name", "Quarkus").data("items", items).render();
        System.err.println(s);

    }
}
